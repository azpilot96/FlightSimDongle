Using a 3.5mm audio cable, connect the wire with continuity with the tip to "Pin 2" on the Arduino and the others to "Ground".
Use an Ardunio Pro Micro or Leonardo.